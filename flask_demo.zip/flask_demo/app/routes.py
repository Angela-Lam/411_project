""" Specifies routing for the application"""
from flask import render_template, request, jsonify, Flask, session,flash
from app import app
from app import database

app.secret_key = 'NickHazelAngela105'
#### Angela's Homepage code
# @app.route("/",methods=['GET'])
# def homepage():
#     """ returns rendered homepage """
#     users = db_helper.fetch_users()
#     return render_template("index.html", users=users)

### Old Index / homepage
# @app.route("/")
# def homepage():
#     items = database.fetch_homepage()
#     return render_template("index.html", items=items)


#current_user = ['guest']
@app.route("/user_info")
def user_info():
    username = session.get('username')
    if username is None or username == 'guest':
        return render_template("login.html")  # Redirect to login if not logged in
    user_info_result = database.get_current_user_info(username)
    if user_info_result:
        user_info = user_info_result[0]  # Get the first (and presumably only) record
        return render_template('user_info.html', current_user_info=user_info)
    

@app.route("/home")
def home():
    name = session.get('username', 'Guest')
    return render_template("home.html", name=name)

@app.route("/")
def login():
    return render_template("login.html")

@app.route("/signup", methods=['GET'])
def signup():
    return render_template("signup.html")

@app.route("/handle_signup", methods=['POST'])
def handle_signup():
    username, password, confirm = request.form['username'], request.form['password'], request.form['password1']
    taken_usernames = database.get_usernames() + ["Guest", "guest"]
    if username in taken_usernames or password != confirm:
        return render_template("signup.html")
    else:
        database.add_user(username, password)
        session['username'] = username
        return render_template("home.html", name=username)

@app.route("/handle_login", methods=['GET', 'POST'])
def handle_login():
    username, password = request.form['username'], request.form['password']
    if (username, password) in database.get_users():
        session['username'] = username  # Set username in session
        return render_template("home.html", name=username)
    else:
        return render_template("login.html", error="Invalid username or password.")

@app.route("/history")
def history():
    """ returns rendered history """
    items = database.fetch_history()
    return render_template("history.html", items=items)

@app.route("/search")
def search():
 
    return render_template("search.html")

@app.route("/favorites")
def favorites():
    """ Returns rendered favorites page """
    username = session.get('username')
    if username is None or username == 'guest':
        return render_template("login.html") # Redirect to login if not logged in
    user_id = database.get_user_id_by_username(username)
    favorite_items = database.fetch_fav(user_id)  
    return render_template("fav.html", items=favorite_items)

@app.route('/logout')
def logout():
    session.pop('username', None)  
    flash('You have been logged out.') 
    return render_template("login.html")

@app.route('/delete_account', methods=['POST'])
def delete_account():
    username = session.get('username')
    if not username:
        return render_template("login.html")
    user_id = database.get_user_id_by_username(username)
    print("userid in delete account", user_id)
    database.delete_user_data(user_id)  # Function to delete user data
    session.pop('username', None)  # Log the user out
    flash('Your account has been deleted.')
    return render_template("login.html")


@app.route("/handle_search", methods=['POST'])
def handle_search():
    keyword = request.form.get("keyword")
    view_count = int(request.form.get('view count'))
    start_date = request.form.get('start-date')
    end_date = request.form.get('end-date')
    category = request.form.get('category')
    sort_by = request.form.get('sort_by')
    print("Keyword: ", keyword)
    print("View Count: ", view_count)
    print("Start Date: ", start_date)
    print("End Date: ", end_date)
    print("Category: ", category)
    print("Sort By: ", sort_by)
    print(type(sort_by))
    if len(keyword) == 0: # Check to see if a keyword is given
        return render_template('search.html')
    

    items = database.fetch_search_results(keyword, view_count, start_date, end_date, category, sort_by)
    return render_template('search_results.html', items=items) 