"""Defines all the functions related to the database"""
from app import db
import sqlalchemy 
from sqlalchemy import create_engine
from datetime import date

def fetch_users() -> list:
    """Reads all user information from the User table

    Returns:
        A list of dictionaries
    """
    conn = db.connect()
    query_results = conn.execute("SELECT * FROM User;").fetchall()
    conn.close()
    users = []
    for result in query_results:
        user = {
            "id": result[0], 
            "username": result[1], 
            "password": result[2], 
            "join_date": result[3] 
        }
        users.append(user)
    return users

def fetch_fav(user_id) -> list:
    user_id = 3
    conn = db.connect()
    query = "SELECT * FROM Favorites WHERE UserId = :user_id;"
    results = conn.execute(sqlalchemy.text(query), {"user_id": user_id}).fetchall()
    conn.close()
    favs = []
    for result in results:
        fav = {
            "VideoId": result[0], 
            "UserId": result[1]
        }
        favs.append(fav)
    return favs

# user is giving us user name, this function finds the unique userid
def get_user_id_by_username(username):
    conn = db.connect()
    try:
        query = "SELECT UserId FROM User WHERE Username = :username;"
        result = conn.execute(sqlalchemy.text(query), {"username": username}).fetchone()
        if result:
            return result[0]  # Return the user ID
        return None
    except Exception as e:
        print("An error occurred while fetching the user ID:", e)
        return None
    finally:
        conn.close()

def delete_user_data(user_id):
    conn = db.connect()
    try:
        conn.execute("DELETE FROM Favorites WHERE UserId = user_id;", {"user_id": user_id})
        conn.execute("DELETE FROM History WHERE UserId = user_id;", {"user_id": user_id})
        conn.execute("DELETE FROM User WHERE UserId = :user_id;", {"user_id": user_id})

    finally:
        conn.close()
# NICK 
def fetch_history() -> dict:
    """Reads all tasks listed in the todo table

    Returns:
        A list of dictionaries
    """

    conn = db.connect()
    query_results = conn.execute("Select * from Search;").fetchall()
    conn.close()
    history_list = []
    for result in query_results:
        item = {
            "SearchId": result[0],
            "Timestamp": result[1],
            "Querry": result[2]
        }
        history_list.append(item)

    return history_list

def fetch_homepage() -> dict:
    """
    Returns:
        A list of dictionaries
    """
    conn = db.connect()
    query_results = conn.execute(sqlalchemy.text("Select * from User;")).fetchall()
    conn.close()
    todo_list = []
    for result in query_results:
        item = {
            "user_id": result[0],
            "username": result[1],
            "password": result[2],
            "join_date": result[3]
        }
        todo_list.append(item)
    return todo_list

def get_usernames():
    conn = db.connect()
    usernames = conn.execute(sqlalchemy.text("Select Username from User;")).fetchall()
    conn.close()
    return usernames

def get_users():
    conn = db.connect()
    users = conn.execute(sqlalchemy.text("Select Username, Password from User;")).fetchall()
    conn.close()
    return users

def add_user(username, password):
    conn = db.connect()
    ids_raw = conn.execute(sqlalchemy.text("Select UserId from User;")).fetchall()
    ids = [i[0] for i in ids_raw]
    new_id = max(ids) + 1
    today = date.today()
    today_int = 10000*today.year + 100*today.month + today.day
    command = "INSERT INTO User VALUES(" + str(new_id) + ", '" + username + "', '" + password + "', " + str(today_int) + ");"
    print(command)
    conn.execute(sqlalchemy.text(command))
    #conn.commit()
    conn.close()

def get_current_user_info(username):
    print ("username,", username)
    conn = db.connect()
    query = "SELECT * FROM User WHERE Username = :username"
    results = conn.execute(sqlalchemy.text(query), {"username": username}).fetchall()
    print ("get current user info", results)
    conn.close()
    return results

def fetch_search_results(keyword, view_count, start_date, end_date, category, sort_by) -> dict:
    """Retrieves the results of the SQL Querry that results from the given parameters

    Returns:
        A list of dictionaries
    """

    # First do keyword Search
    if len(keyword) != 0: # Check to see if a keyword is given
        # Initialize the querry string since keyword is required
        querry_string = ("SELECT V.Title, C.ChannelName, Ca.CategoryName, V.PublishTime, V.ViewCount, V.Likes, V.TrendingDate FROM (Video V LEFT JOIN Channel C on V.ChannelId = C.ChannelId) LEFT JOIN Category Ca on V.CategoryId = Ca.CategoryId WHERE V.Title LIKE '%%" + keyword + "%%'")
    if view_count != 0:
        # My python is not up-to-date enough to use switch :(
        if view_count == 1: # 0-100000
            querry_string += " AND V.ViewCount <= 100000"   
        elif view_count == 2: # 100001-500000
            querry_string += " AND V.ViewCount > 100000 AND V.ViewCount <= 500000"
        elif view_count == 3: # 500001-1000000
            querry_string += " AND V.ViewCount > 500000 AND V.ViewCount <= 1000000"
        elif view_count == 4: # 1000001-2000001
            querry_string += " AND V.ViewCount > 1000000 AND V.ViewCount <= 2000000"
        elif view_count == 5: # Larger
            querry_string += " AND V.ViewCount > 2000000"
        else:  
            print("How 1??")
    if len(start_date) != 0:
        querry_string += f" AND V.PublishTime > '{start_date}'"  

    if len(end_date) != 0:
        querry_string += f" AND V.PublishTime < '{end_date}'" 

    if category != "0":
        querry_string += f" AND V.CategoryId = {category}"

    if sort_by != "0":
        if sort_by == "1": # Category
            querry_string += " ORDER BY Ca.CategoryName DESC"  
        elif sort_by == "2": # Publish Date
            querry_string += " ORDER BY V.PublishTime DESC"
        elif sort_by == "3": # View Count
            querry_string += " ORDER BY V.ViewCount DESC"
        elif sort_by == "4": # Likes
            querry_string += " ORDER BY V.Likes DESC"
        elif sort_by == "5": # Trending Date
            querry_string += " ORDER BY V.TrendingDate DESC"
        else:  
            print("How 2??")

    querry_string += " LIMIT 50;"

    print(querry_string)
    conn = db.connect()
    query_results = conn.execute(querry_string).fetchall()
    conn.close()
    search_results_list = []
    for result in query_results:
        item = {
            "Title": result[0],
            "ChannelName": result[1],
            "Category": result[2],
            "PublishTime": result[3],
            "ViewCount": result[4],
            "Likes": result[5],
            "TrendingDate": result[6]
            # "VideoId": result[0],
            # "Title": result[1],
            # "ChannelId": result[2],
            # "CategoryId": result[3],
            # "Description": result[4],
            # "PublishTime": result[5],
            # "ViewCount": result[6],
            # "CommentCount": result[7],
            # "Likes": result[8],
            # "TrendingDate": result[9]
        }
        search_results_list.append(item)
    # print(search_results_list)
    return search_results_list


def update_task_entry(task_id: int, text: str) -> None:
    """Updates task description based on given `task_id`

    Args:
        task_id (int): Targeted task_id
        text (str): Updated description

    Returns:
        None
    """

    conn = db.connect()
    query = 'Update tasks set task = "{}" where id = {};'.format(text, task_id)
    conn.execute(query)
    conn.close()


def update_status_entry(task_id: int, text: str) -> None:
    """Updates task status based on given `task_id`

    Args:
        task_id (int): Targeted task_id
        text (str): Updated status

    Returns:
        None
    """

    conn = db.connect()
    query = 'Update tasks set status = "{}" where id = {};'.format(text, task_id)
    conn.execute(query)
    conn.close()


def insert_new_task(text: str) ->  int:
    """Insert new task to todo table.

    Args:
        text (str): Task description

    Returns: The task ID for the inserted entry
    """

    conn = db.connect()
    query = 'Insert Into tasks (task, status) VALUES ("{}", "{}");'.format(
        text, "Todo")
    conn.execute(query)
    query_results = conn.execute("Select LAST_INSERT_ID();")
    query_results = [x for x in query_results]
    task_id = query_results[0][0]
    conn.close()

    return task_id


def remove_task_by_id(task_id: int) -> None:
    """ remove entries based on task ID """
    conn = db.connect()
    query = 'Delete From tasks where id={};'.format(task_id)
    conn.execute(query)
    conn.close()

